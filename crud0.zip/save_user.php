<?php
include("db.php");
function formatearNombre($nombre)
{
	$nombre = strtolower($nombre);
	$nombre = ucwords($nombre);
	return $nombre;
}

if (isset($_POST['save_user'])) {
	$name = formatearNombre($_POST['name']);
	$lastname = formatearNombre($_POST['lastname']);
	$dni = $_POST['dni'];
	$birthdate = $_POST['birthdate'];
	$age = $_POST['age'];
	$query = "INSERT INTO users(name, lastname, dni, birthdate, age) VALUES ('$name', '$lastname', '$dni', '$birthdate', '$age')";
	$result = mysqli_query($conn, $query);
	if (!$result) {
		die("Query Failed");
	}
	echo strlen($name);
	$_SESSION['message'] = "User Saved Succesfully";
	$_SESSION['message_type'] = "success";
	header("location: index.php");
}
?>