<?php include("db.php") ?>
<?php include("includes/header.php") ?>
<div class="container-fluid p-4">
 <div class="row">
  <div style="width:28%;">
   <?php if (isset($_SESSION['message'])) { ?>
    <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
     <?= $_SESSION['message'] ?>
     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php session_unset();
   } ?>
   <div class="card card-body">
    <form action="save_user.php" method="POST">
     <div class="form-group mb-3">
      <input type="text" name="name" class="form-control" placeholder="Name" autocomplete="off" autofocus>
     </div>
     <div class="form-group mb-3">
      <input type="text" name="lastname" class="form-control" placeholder="Lastname" autocomplete="off" autofocus>
     </div>
     <div class="form-group mb-3">
      <input type="text" name="dni" class="form-control" placeholder="DNI" autocomplete="off" autofocus>
     </div>
     <div class="form-group mb-3">
      <input type="date" name="birthdate" class="form-control" placeholder="Birthdate (2000-11-02)" autocomplete="off"
       autofocus>
     </div>
     <div class="form-group mb-3">
      <input type="text" name="age" class="form-control" placeholder="Age" autocomplete="off" autofocus>
     </div>
     <input type="submit" class="btn btn-primary w-100" name="save_user" value="Save User">
    </form>
   </div>
  </div>
  <div id="show" class="col-md-8">
   <table class="table table-bordered text-center">
    <thead>
     <tr>
      <th>Nro</th>
      <th>Name</th>
      <th>Lastname</th>
      <th>DNI</th>
      <th>Birthdate</th>
      <th>Age</th>
      <th>Actions</th>
     </tr>
    </thead>
    <tbody>
     <?php
     $query = "SELECT * FROM users";
     $result_task = mysqli_query($conn, $query);
     $contador = 1;
     while ($row = mysqli_fetch_array($result_task)) { ?>
      <tr>
       <td><?php echo $contador; ?></td>
       <td><?php echo $row['name'] ?> </td>
       <td><?php echo $row['lastname'] ?> </td>
       <td><?php echo $row['dni'] ?> </td>
       <td><?php echo $row['birthdate'] ?> </td>
       <td><?php echo $row['age'] ?> </td>
       <td>
        <div class="d-flex">
         <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm me-1 w-50">
          <i class="fas fa-edit"></i> Edit
         </a>
         <a href="delete_user.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm w-50">
          <i class="fas fa-trash-alt"></i> Delete
         </a>
        </div>
       </td>
      </tr>
      <?php
      $contador++;
     }
     ?>
    </tbody>
   </table>
  </div>
 </div>
</div>

<?php include("includes/footer.php") ?>