<?php
include("db.php");

if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$query = "SELECT * FROM users WHERE id = $id";
	$result = mysqli_query($conn, $query);
	if (mysqli_num_rows($result) == 1) {
		$row = mysqli_fetch_array($result);
		$name = $row['name'];
		$lastname = $row['lastname'];
		$dni = $row['dni'];
		$birthdate = $row['birthdate'];
		$age = $row['age'];
	}
}

if (isset($_POST['update'])) {
	$id = $_GET['id'];
	$name = $_POST['name'];
	$lastname = $_POST['lastname'];
	$dni = $_POST['dni'];
	$birthdate = $_POST['birthdate'];
	$age = $_POST['age'];
	$query = "UPDATE users set name = '$name', lastname = '$lastname', dni = '$dni', birthdate = '$birthdate', age = '$age' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: index.php");
}
?>
<?php include('includes/header.php') ?>
<div class="container p-4">
	<div class="row">
		<div class="col-md-4 mx-auto">
			<div class="card card-body mb-3">
				<form action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST" class="text-center">
					<div class="form-group mb-3">
						<input type="text" name="name" value="<?php echo $name; ?>" class="form-control"
							placeholder="name">
					</div>
					<div class="form-group mb-3">
						<input type="text" name="lastname" value="<?php echo $lastname; ?>" class="form-control"
							placeholder="Lastname">
					</div>
					<div class="form-group mb-3">
						<input type="text" name="dni" value="<?php echo $dni; ?>" class="form-control"
							placeholder="25980542">
					</div>
					<div class="form-group mb-3">
						<input type="text" name="birthdate" value="<?php echo $birthdate; ?>" class="form-control">
					</div>
					<div class="form-group mb-3">
						<input type="text" name="age" value="<?php echo $age; ?>" class="form-control" placeholder="22">
					</div>
			</div>
			<button class="btn btn-primary w-100" name="update">Update</button>
			</form>
		</div>
	</div>
</div>

<?php include('includes/footer.php') ?>