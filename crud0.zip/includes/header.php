<!DOCTYPE html>
<html>
<head>
 <title>CONEXION MYSQL CRUD</title>
 <link rel="stylesheet" type="text/css" href="./statics/css/bootstrap.min.css">
 <style>
  .form-control {
   text-align: center !important;
  }
  #show {
   height: 75vh;
   overflow: auto;
  }

  #searchBtn {
   display: none;
  }
 </style>
</head>
<body>
 <nav class="navbar navbar-dark bg-dark">
  <div class="container">
   <a href="#" class="navbar-brand">PHP MYSQL CRUD OF USERS</a>
   <div class="d-flex">
    <input type="text" id="searchDni" placeholder="Find for DNI..." class="form-control me-2 outline-light">
    <button id="searchBtn">Buscar</button>
   </div>
  </div>
 </nav>
 <script>
  document.addEventListener('DOMContentLoaded', function () {
   const searchDni = document.getElementById('searchDni');
   const searchBtn = document.getElementById('searchBtn');
   const tableRows = document.querySelectorAll('tbody tr');
   function filterTable() {
    const searchTerm = searchDni.value.trim().toLowerCase();
    tableRows.forEach(row => {
     const dniCell = row.querySelector('td:nth-child(4)');
     const dniText = dniCell.textContent.toLowerCase();
     if (dniText.includes(searchTerm)) {
      row.style.display = '';
     } else {
      row.style.display = 'none';
     }
    });
   }
   searchBtn.addEventListener('click', filterTable);
   searchDni.addEventListener('keyup', function (e) {
    if (e.key === 'Enter') {
     filterTable();
    }
   });
   searchDni.addEventListener('input', filterTable);
  });
 </script>