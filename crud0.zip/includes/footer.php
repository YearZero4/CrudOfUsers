<!-- SCRIPTS -->
<script type="text/javascript" src="./statics/js/bootstrap.bundle.min.js"></script>
</body>
</html>